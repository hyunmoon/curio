# Recorded outcomes

These are results from the original independent PostgreSQL investigation. The package editor inspected the code and logs and did not rerun Go, database or native tests.

| Scenario | Before | After | Meaning |
| --- | --- | --- | --- |
| Retry committed timestamp through peer serialization | Intended assertion FAIL | PASS; race PASS | Clock lost before, preserved after. Actual DB polling returns the correct timestamp on both. |
| Stale success/retryable failure/terminal failure/preemption | Four intended assertions FAIL | PASS; race PASS | Before alters the replacement task and writes stale history. The old success also publishes a callback. After preserves the replacement and permits its own completion. |
| SDR success-write/completion gap | Characterization PASS | Characterization PASS; race PASS | Both can leave a surviving task without a pipeline reference. No orphan repair is claimed. |
| Orphan candidate selection | Intended assertion FAIL | PASS; race PASS | After excludes a missing-reference task. |
| One-slot actual handler without pacing | Intended assertion FAIL; next-pass progress confirmed | PASS with race | Before wastes its first admission, then progresses. After starts valid work on the first pass. |
| Delayed poll snapshot re-links completed SDR | Intended assertion FAIL | PASS; race PASS | Both producers re-link; after filtering refuses the new completed-reference task. |
| Actual SectorRemove with empty file locations | Characterization PASS | Characterization PASS; race PASS | Pipeline removed, normally created task remains. No file or chain operations. |
| Fresh duplicate migration receipts and restart | Not applicable | PASS | Current candidate fresh/restart succeeds; two same-date receipts are observed. This does not justify the new upstream migration layout. |

## Initial failures retained

- before-ab.log: adapter compilation failure.
- before-ab-compiled.log and after-ab.log: fixture registration failures.
- before-c.log: adapter compilation failure.
- after-causal-race.log: pre-existing PDP migration catalog lookup interfered across concurrent fresh schemas. The API package passed. Affected packages passed on the serial rerun in after-causal-race-serial.log.

None of those setup failures is counted as a red control. Product runtime and migration files were not changed to obtain the results.

## Extracted log records

### before-ab-ready.log

```text
    causal_common_test.go:63: committed=2026-09-15T04:46:50.598674+09:00 wire={"verb":"newTask","taskID":1,"other":{"taskType":"SDR","retries":1,"posted":"2026-09-15T04:46:50.594634+09:00"}} received=2026-09-15T04:46:50.628063+09:00 already_due=true peer_due=false
    causal_common_test.go:85: normal AddTask -> claim A -> real CleanupMachines -> claim B -> late A; mode=success task_preserved=false history=1 callbacks=1
    causal_common_test.go:85: normal AddTask -> claim A -> real CleanupMachines -> claim B -> late A; mode=retryable-failure task_preserved=false history=1 callbacks=0
    causal_common_test.go:85: normal AddTask -> claim A -> real CleanupMachines -> claim B -> late A; mode=terminal-failure task_preserved=false history=1 callbacks=0
    causal_common_test.go:85: normal AddTask -> claim A -> real CleanupMachines -> claim B -> late A; mode=preemption task_preserved=false history=1 callbacks=0
```

### after-ab-ready.log

```text
    causal_common_test.go:63: committed=2026-09-15T04:46:53.365963+09:00 wire={"verb":"newTask","taskID":1,"other":{"taskType":"SDR","retries":1,"posted":"2026-09-15T04:46:53.363999+09:00","updateTime":"2026-09-15T04:46:53.365963+09:00"}} received=2026-09-15T04:46:53.365963+09:00 already_due=true peer_due=true
    causal_common_test.go:85: normal AddTask -> claim A -> real CleanupMachines -> claim B -> late A; mode=success task_preserved=true history=0 callbacks=0
    causal_common_test.go:85: normal AddTask -> claim A -> real CleanupMachines -> claim B -> late A; mode=retryable-failure task_preserved=true history=0 callbacks=0
    causal_common_test.go:85: normal AddTask -> claim A -> real CleanupMachines -> claim B -> late A; mode=terminal-failure task_preserved=true history=0 callbacks=0
    causal_common_test.go:85: normal AddTask -> claim A -> real CleanupMachines -> claim B -> late A; mode=preemption task_preserved=true history=0 callbacks=0
```

### before-admission.log

```text
    causal_admission_test.go:14: source=before one-slot real handler, no pacing: first_pass_started=false storage_resolver_calls=[1 2]; valid task completed; a second upstream pass can progress
```

### after-admission.log

```text
    causal_admission_test.go:14: source=after one-slot real handler, no pacing: first_pass_started=true storage_resolver_calls=[2]; valid task completed; a second upstream pass can progress
```

### before-c-ready.log

```text
    causal_sdr_test.go:54: delayed normal poll snapshot linked new task 2 after completed task 1; selected=[2]
```

### after-c-ready.log

```text
    causal_sdr_test.go:54: delayed normal poll snapshot linked new task 2 after completed task 1; selected=[]
```

### after-migration.log

```text
    causal_migration_test.go:36: fresh actual runner: 20260909=2 20260910=1 20260912=1; both telemetry families+generation present; restart ledger unchanged
```

## Limits

These are targeted function/SQL executions with native work substituted. The crash boundary omits the later completion call rather than terminating an FFI process. The completed-reference test schedules a stale snapshot deliberately. No production incident attribution, full scheduler process test, native termination guarantee, fleet throughput measurement or fresh Yugabyte result follows.
