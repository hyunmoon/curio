# Minimal scenarios and assertions

Sources: before 86e95967cd602dbf8db5ea538abe986c3968e2e3; after
0c1f7cbd4dc9797e9773f1edd165af6b72d3fe27. All setup is disposable.

## A — retry delivery

Normal `AddTaskByName` -> actual claim -> `recordCompletion(false,error)` -> read
committed retries=1/update_time -> actual `emitRetryTask` waits the 25ms fixture
RetryWait -> actual `TellNewTask` JSON through the repository in-memory peer
transport -> actual `handlePeerMessage` -> `taskFromSchedulerEvent`.

Assertions: original deadline is already due; received timestamp equals the
committed timestamp; peer deadline is due; actual DB polling returns that same
committed timestamp. Before has no updateTime in the wire payload and synthesizes
receipt time; after retains it. This is not a socket/latency test. DB polling can
repair the old receiver, so no universal 2x-delay or missing-failover assertion.

## B — stale completion

Normal AddTask/claim A -> artificially expire only A's heartbeat -> real
CleanupMachines removes A and FK nulls task ownership -> independent pool and
another handler claim B -> retain complete row JSON -> deliver A's late result.

Four outcomes: success, ordinary retryable failure, terminal failure,
preemption. Expected: B's entire row/clock/budget unchanged; zero ordinary
history rows and callbacks from A. Candidate then permits B's current successful
completion/history. Before success deletes B's task and publishes a success
callback; retryable/preempt disown B (ordinary failure increments retries);
terminal failure deletes B's task. All write stale history.

This reproduces the real cleanup/reclaim/completion boundary, not an OS pause or
whole scheduler/native run. The test explicitly invokes completion, whereas the
separate C handler test drives real dispatch and completion with a substitute Do.
Prior exact-source tests cover same-owner/token/generation changes and an actual
independent SQL lock holder; they were not needlessly repeated here.

## C1 — orphan is produced, not inserted

Seed an ordinary new pipeline sector (no task). Real `SDRTask.Adder` registers
the real `pollStartSDR` -> engine `AddTaskByName` callback. Assert exactly one
new task and one link committed together. Execute the exact production success
UPDATE block with fixture ticket values; after_sdr=true/task_id_sdr=NULL commits.
Do not execute the later independent scheduler completion (modeled crash).
Assert task exists, link count=0, and actual storage resolver fails. Both sources
exhibit this state. The filter is not a fix for this non-atomic lifecycle gap.

## C2 — admission effect without pacing

Create the C1 orphan plus a valid normally-created task. Supply bad first to the
real handler with one resource slot and normal unpaced SDR CanAccept. Substitute
native Do with a channel barrier and physical Claim with the actual taskToSector
resolver. Before claims/releases bad on pass one, starts/completes good on pass
two while bad is in cooldown. After filters bad and starts/completes good on pass
one. Assertions fail before and pass after. Deliberate oldest/bad-first ordering
is a fixture condition, not the recorded SQL order of the production snapshot.

This proves wasted admission, not permanent starvation, wall-time SLA or reduced
fleet throughput. The prior larger personal-pacer model amplifies delay only
under its stated ordering/cadence/cooldown assumptions.

## C3 — completed reference has a normal producer path

Read a real pollTask snapshot while task_id_sdr=NULL/after_sdr=false. First normal
poller/AddTask creates task A. Exact success SQL commits after_sdr=true and clears
the task ID. Resume a poller with the saved snapshot: the actual producer UPDATE
only rechecks NULL task ID, so it creates/links a different task B even though
after_sdr=true. Before admits B; candidate filter rejects B. A delayed earlier
snapshot is intentional fault scheduling, not a manually malformed task link.

The test invokes the same poller object with the saved snapshot; that represents
the stale observation of a delayed independent poller, not two simultaneous live
poller loops. No native body or elapsed-hour timing is simulated.

## C4 — legacy API comparison

Create a normal SDR task/link, invoke actual legacy `SectorRemove` on the empty
storage-location fixture. Assert pipeline gone/task remains, both versions.
The source separately deletes batch refs, SDR and Snap pipeline, then inserts
unapproved GC marks. This test has no file rows and invokes no file/chain API.
It is not evidence that this API was used on the reported incident task.

## Migration contract

The pinned loader loads landed date prefixes once at startup, applies sorted
files and records name[:8] without updating its landed map. Two new 20260909
files therefore both run on fresh startup, producing two actual receipts.
On a subsequent startup with just one historical 20260909 already present,
both names match that receipt. Q5's 20260910 forward reconcile handles that
history; the new small test confirms full fresh/restart behavior only. Historical
partial/failure runner evidence is archived separately. No fake ledger writes.
