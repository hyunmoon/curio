//go:build causal && !skiff

package harmonytask

import (
	"context"
	"github.com/filecoin-project/curio/harmony/harmonydb"
)

// Test-only access to the normal transactional producer; no scheduler services start.
func CausalAdder(ctx context.Context, db *harmonydb.DB, owner int) AddTaskFunc {
	e := &TaskEngine{cfg: taskEngineConfig{ctx: ctx, db: db, ownerID: owner}}
	return func(extra func(TaskID, *harmonydb.Tx) (bool, error)) { e.AddTaskByName("SDR", extra) }
}
