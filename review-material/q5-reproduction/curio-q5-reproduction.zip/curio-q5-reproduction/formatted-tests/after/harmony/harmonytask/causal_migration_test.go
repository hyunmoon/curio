//go:build causal && !skiff

package harmonytask

import (
	"testing"

	"github.com/stretchr/testify/require"

	"github.com/filecoin-project/curio/harmony/harmonydb"
)

func TestCausalFreshDuplicateMigrationReceiptsAndRestart(t *testing.T) {
	ctx, db, _ := causalDB(t)
	var nine, ten, twelve int
	var schema, before, after string
	require.NoError(t, db.QueryRow(ctx, `SELECT current_schema(),
 (SELECT count(*) FROM base WHERE entry='20260909'),
 (SELECT count(*) FROM base WHERE entry='20260910'),
 (SELECT count(*) FROM base WHERE entry='20260912'),
 (SELECT jsonb_agg(to_jsonb(b) ORDER BY id)::text FROM base b)`).Scan(&schema, &nine, &ten, &twelve, &before))
	require.Equal(t, 2, nine, "fresh loader applies both same-prefix files before rebuilding landed map")
	require.Equal(t, 1, ten)
	require.Equal(t, 1, twelve)
	_, err := db.Exec(ctx, `SELECT work_start,work_start_source,attempt_id,attempt_started_at,attempt_start_source,owner_generation FROM harmony_task`)
	require.NoError(t, err)
	// Actual runner startup again; no manual ledger insertion/deletion or SQL-file Exec.
	restarted, err := harmonydb.NewFromConfig(harmonydb.Config{
		Hosts: []string{"127.0.0.1"}, Port: "59591", Database: "causal_disposable",
		Username: "causal_fixture", Schema: schema, ReadOnly: false, LoadBalance: false,
	})
	require.NoError(t, err)
	t.Cleanup(restarted.ITestDeleteAll)
	require.NoError(t, restarted.QueryRow(ctx, `SELECT jsonb_agg(to_jsonb(b) ORDER BY id)::text FROM base b`).Scan(&after))
	require.Equal(t, before, after, "restart preserves real receipts")
	t.Logf("fresh actual runner: 20260909=%d 20260910=%d 20260912=%d; both telemetry families+generation present; restart ledger unchanged", nine, ten, twelve)
}
