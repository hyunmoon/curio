//go:build causal && !skiff

package webrpcporep

import (
	"context"
	"github.com/filecoin-project/curio/deps"
	"github.com/filecoin-project/curio/harmony/harmonydb"
	"github.com/filecoin-project/curio/tasks/seal"
	"github.com/filecoin-project/curio/web/api/webrpc"
	"github.com/stretchr/testify/require"
	"os"
	"testing"
	"time"
)

const causalVersion = "after"

func causalDB(t *testing.T) (context.Context, *harmonydb.DB, *harmonydb.DB) {
	t.Helper()
	if os.Getenv("CURIO_CAUSAL_ITEST") != "1" {
		t.Skip("explicit disposable fixture opt-in required")
	}
	require.Equal(t, "127.0.0.1", os.Getenv("CURIO_CAUSAL_ITEST_HOST"))
	require.Equal(t, "59591", os.Getenv("CURIO_CAUSAL_ITEST_PORT"))
	require.Equal(t, "causal_disposable", os.Getenv("CURIO_CAUSAL_ITEST_DATABASE"))
	require.Equal(t, "causal_fixture", os.Getenv("CURIO_CAUSAL_ITEST_USER"))
	opts := harmonydb.ItestOptions{Hosts: []string{"127.0.0.1"}, Port: "59591", Database: "causal_disposable", Username: "causal_fixture", ITestID: harmonydb.ITestNewID()}
	cfg := opts.HarmonyConfig()
	cfg.ReadOnly = false
	cfg.LoadBalance = false
	db, err := harmonydb.NewFromConfig(cfg)
	require.NoError(t, err)
	t.Cleanup(db.ITestDeleteAll)
	cfg.ReadOnly = true
	other, err := harmonydb.NewFromConfig(cfg)
	require.NoError(t, err)
	t.Cleanup(other.ITestDeleteAll)
	ctx, cancel := context.WithTimeout(context.Background(), 20*time.Second)
	t.Cleanup(cancel)
	_, err = db.Exec(ctx, `INSERT INTO harmony_machines(id,host_and_port,cpu,ram,gpu) VALUES(101,'worker-a.example',4,1024,0),(102,'worker-b.example',4,1024,0)`)
	require.NoError(t, err)
	var version, schema string
	require.NoError(t, db.QueryRow(ctx, `SELECT version(),current_schema()`).Scan(&version, &schema))
	require.Contains(t, schema, "itest_")
	t.Logf("source=%s database=%s schema=%s; real embedded migration runner", causalVersion, version, schema)
	return ctx, db, other
}

func TestCausalLegacyRemoveOrphansTask(t *testing.T) {
	ctx, db, _ := causalDB(t)
	_, id := seal.CausalCreateSDR(t, ctx, db, 1000, 42)
	a := New(&webrpc.Handler{Deps: &deps.Deps{DB: db}})
	require.NoError(t, a.SectorRemove(ctx, 1000, 42))
	var tasks, pipeline int
	require.NoError(t, db.QueryRow(ctx, "SELECT (SELECT count(*) FROM harmony_task WHERE id=$1),(SELECT count(*) FROM sectors_sdr_pipeline WHERE sp_id=1000 AND sector_number=42)", id).Scan(&tasks, &pipeline))
	require.Equal(t, 1, tasks)
	require.Zero(t, pipeline)
	t.Log("actual legacy SectorRemove left the normally-created Harmony task; empty file locations, no file/chain RPC invoked")
}
