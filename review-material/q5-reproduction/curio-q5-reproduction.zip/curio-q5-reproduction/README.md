# Curio #1533 reproduction material

This package accompanies a review response for [PR #1533](https://github.com/filecoin-project/curio/pull/1533).
It contains existing test-only overlays and recorded evidence, repackaged for review.
**Packaging did not rerun the tests or change their code.** Results below describe the original independent investigation.

## Sources

| Variant | Commit |
| --- | --- |
| before | `86e95967cd602dbf8db5ea538abe986c3968e2e3` |
| after | `0c1f7cbd4dc9797e9773f1edd165af6b72d3fe27` |

The before source is in filecoin-project/curio; the after source is the reviewed PR head in hyunmoon/curio.
The package does not include a Git repository, binary, database, credentials or native FFI artifacts.
Existing PR refs are not modified by these instructions.

## Contents

- `tests/before/` and `tests/after/`: exact test-only files used for the recorded executions.
- `formatted-tests/`: existing gofmt-normalized copies for reading; their hashes are recorded separately.
- `source-excerpts/`: unchanged success-write, claim and publication fragments extracted from the pinned source.
- `SCENARIOS.md`: setup, assertions and limits.
- `RESULTS.md`: recorded outcomes, including initial fixture failures.
- `logs/`: original text logs with only local filesystem path prefixes replaced. Assertions and outcomes are retained.
- `receipts.json`: source identities, commands and exit codes from the original run, without local environment paths.
- `MANIFEST.json`: source file and original/packaged hash correspondence.
- `SHA256SUMS`: checksums for the package contents.

The original review archive had SHA-256
`470d2af22188242b4aedfd714054cf113cefeb5ed43e3a06a819d58e2ce9b5e4`.
This is a new, narrower package; that hash is **not** its checksum.

## Environment and boundaries

Recorded environment: Go 1.26.1, Darwin/arm64, PostgreSQL 16.15, existing OpenCL FFI link artifacts, tags `causal,cgo,fvm,nosupraseal`.
Native proofs, live heartbeat/network failure, production, Linux and Yugabyte were not run in this investigation.

The before adapters call the original completion and peer functions. Before ownership claim SQL and the publication suffix are extracted unchanged because that source does not expose equivalent callable helpers.
The after adapters call the candidate helpers. Both variants share the causal assertions.
SDR tests run normal pollStartSDR/AddTask linking and the unchanged success SQL block; the full native SDR.Do prefix is not executed.
The delayed snapshot is an intentional schedule of function calls, not two live poller processes.

## Prepare disposable checkouts

Use independent disposable checkouts at the exact commits above, not an operational checkout.
Confirm `git rev-parse HEAD` before copying files.
Populate their pinned submodules and prepare compatible FFI link dependencies using the project build procedure for those commits.
The original run reused those dependencies; this package is not a replacement for the Curio build environment.

Copy the contents of `tests/before/` into the before checkout and `tests/after/` into the after checkout, retaining relative paths.
Every addition is gated by `causal && !skiff`. Do not copy both variants into one checkout.
Before running, `git diff --exit-code` should show no changes to tracked product files.
The added test files are expected to be untracked.

## Owned PostgreSQL only

The fixtures enforce all of these values:

- `CURIO_CAUSAL_ITEST=1`
- host `127.0.0.1`, port `59591`
- database `causal_disposable`, user `causal_fixture`

Use a newly created, owned PostgreSQL cluster. A matching address alone does not establish ownership.
The tests create and drop random `itest_*` schemas through the real embedded migration runner.
No operating database may be used.

For a PostgreSQL 16.15 installation on PATH, the following prepares the same database settings in a new directory.
Run as an ordinary user in a dedicated shell. Stop if any command fails; do not proceed to createdb if pg_ctl could not bind the port.

```bash
set -euo pipefail
CURIO_REPRO_DB_ROOT="$(mktemp -d "${TMPDIR:-/tmp}/curio-q5-db.XXXXXX")"
initdb -D "$CURIO_REPRO_DB_ROOT/pgdata" -U causal_fixture -A trust --locale=C --encoding=UTF8
pg_ctl -D "$CURIO_REPRO_DB_ROOT/pgdata" -l "$CURIO_REPRO_DB_ROOT/postgres.log" \
  -o "-h 127.0.0.1 -p 59591 -k '' -c max_connections=50 -c shared_buffers=32MB -c statement_timeout=10000 -c idle_in_transaction_session_timeout=15000" \
  -w start
createdb -h 127.0.0.1 -p 59591 -U causal_fixture causal_disposable
```

These portable preparation commands were not executed during repackaging. The recorded investigation used the same PostgreSQL settings from its local launcher.

## Run the causal tests

Run each command from the corresponding prepared checkout, in a clean test environment.
Do not inherit operational Curio, libpq or other integration-test variables.
An explicit environment suitable for the recorded OpenCL build is shown below; local FFI linker paths, if needed, must be supplied from the reviewer's own build environment.

```bash
run_q5_test() {
  env -i PATH="$PATH" HOME="$HOME" TMPDIR="${TMPDIR:-/tmp}" \
    GOENV=off GOTOOLCHAIN=local GOPROXY=off GOSUMDB=off \
    CGO_ENABLED=1 FFI_USE_OPENCL=1 GOMAXPROCS=2 \
    CURIO_CAUSAL_ITEST=1 CURIO_CAUSAL_ITEST_HOST=127.0.0.1 \
    CURIO_CAUSAL_ITEST_PORT=59591 \
    CURIO_CAUSAL_ITEST_DATABASE=causal_disposable \
    CURIO_CAUSAL_ITEST_USER=causal_fixture \
    go test -p=1 -tags=causal,cgo,fvm,nosupraseal \
      -count=1 -timeout=90s "$@"
}
```

Dependencies must already be available because module network downloads are disabled.
The fixtures require schema-create/drop privileges, supplied by the role in the owned cluster above.
Use `-p=1`: an unrelated pre-existing PDP migration has a schema-unqualified catalog lookup and interferes with simultaneous fresh schemas.
This keeps the tests' independent database connections and contention intact.

Run these separately on each variant, preserving nonzero exits:

```bash
run_q5_test -run '^TestCausal(Retry|Stale)' -v ./harmony/harmonytask
run_q5_test -run '^TestCausal(SDR|Legacy)' -v ./tasks/seal ./web/api/webrpcporep
```

The second command includes the actual-handler test. The original investigation also ran that test separately:
```bash
run_q5_test -run '^TestCausalSDRActualHandler' -v ./tasks/seal
```

On the after checkout, also run:
```bash
run_q5_test -race -run '^TestCausal' -v ./harmony/harmonytask ./tasks/seal ./web/api/webrpcporep
run_q5_test -run '^TestCausalFreshDuplicate' -v ./harmony/harmonytask
```

A before failure is expected only at the documented invariant assertions.
A compiler, database setup or timeout failure is not a successful reproduction.
Do not let shell `set -e` turn an expected before assertion into an unexplained interruption; capture that exit and run the next variant deliberately.
The exact historical command groups and initial failures are in `receipts.json`; the consolidated commands above are a reproduction guide, not a claim of another execution.

When finished, stop only the cluster created above:
```bash
pg_ctl -D "$CURIO_REPRO_DB_ROOT/pgdata" -m fast -w stop
```
Do not remove the directory until the results have been inspected.

## Interpretation

The tests establish specific scheduler and SQL behavior. They do not establish the cause of the reported historical orphan rows or justify all 47 changed files as a minimal fix.
Missing-reference and completed-reference filtering are admission mitigations; Q5 still permits their demonstrated producer states.
No normal ambiguous producer or independently necessary failed-but-SDR-incomplete case was established.

