//go:build causal && !skiff

package harmonytask
import("testing";"time";"github.com/stretchr/testify/require")
const causalVersion="before"
type causalIdentity struct{}
type causalResult struct{}
func causalClaim(t *testing.T,h *taskTypeHandler,row task)causalIdentity{t.Helper();var tasksAccepted []TaskID;tIDs:=[]TaskID{row.ID};maxAcceptable:=1;err:=h.TaskEngine.cfg.db.Select(h.TaskEngine.cfg.ctx,&tasksAccepted,`
		WITH candidates AS (
			SELECT t.id
			FROM harmony_task t
			JOIN unnest($2::bigint[]) AS x(id) ON x.id = t.id
			WHERE t.owner_id IS NULL
			ORDER BY array_position($2, t.id::bigint)
			LIMIT $3
			FOR UPDATE SKIP LOCKED
		)
		UPDATE harmony_task t
		SET owner_id = $1
		FROM candidates c
		WHERE t.id = c.id
		RETURNING t.id;`,h.TaskEngine.cfg.ownerID,tIDs,maxAcceptable);require.NoError(t,err);require.Equal(t,tIDs,tasksAccepted);return causalIdentity{}}
func causalComplete(h *taskTypeHandler,row task,done bool,doErr error,preempted bool,_ causalIdentity)causalResult{h.recordCompletion(row.ID,nil,time.Now(),done,doErr,preempted);return causalResult{}}
func causalEmit(h *taskTypeHandler,ee eventEmitter,row task,_ causalResult){h.emitRetryTask(ee,row,false)}
func causalTell(p *peering,e schedulerEvent){p.TellNewTask(e.TaskType,e.TaskID,e.Retries,e.PostedTime)}
func causalPublish(h *taskTypeHandler,row task,_ causalResult,done bool,doErr error,_ bool){tID:=row.ID;meta:=&completionMeta{vals:map[any]any{}};eventEmitter:=eventEmitter{schedulerChannel:h.TaskEngine.schedulerChannel};				success := done && doErr == nil
				if success {
					h.TaskEngine.invokeTaskCompleteCallbacks(h.Name, meta, tID)
				}
				eventEmitter.EmitTaskCompleted(h.Name, success)
}
