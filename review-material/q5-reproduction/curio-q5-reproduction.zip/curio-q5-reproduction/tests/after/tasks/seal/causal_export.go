//go:build causal && !skiff
package seal
import("context";"testing";"github.com/stretchr/testify/require";"golang.org/x/xerrors";"github.com/filecoin-project/go-state-types/abi";"github.com/filecoin-project/curio/harmony/harmonydb";"github.com/filecoin-project/curio/harmony/harmonytask")
// Runs real pollStartSDR -> AddTaskByName with the normal transactional extra callback.
func CausalCreateSDR(t *testing.T,ctx context.Context,db *harmonydb.DB,miner,sector int64)(*SDRTask,harmonytask.TaskID){t.Helper();_,err:=db.Exec(ctx,"INSERT INTO sectors_sdr_pipeline(sp_id,sector_number,reg_seal_proof) VALUES($1,$2,0)",miner,sector);require.NoError(t,err);p:=&SealPoller{db:db};s:=&SDRTask{db:db,sp:p};s.Adder(harmonytask.CausalAdder(ctx,db,101));p.pollStartSDR(ctx,pollTask{SpID:miner,SectorNumber:sector});var id harmonytask.TaskID;require.NoError(t,db.QueryRow(ctx,"SELECT task_id_sdr FROM sectors_sdr_pipeline WHERE sp_id=$1 AND sector_number=$2",miner,sector).Scan(&id));return s,id}
// Mechanically extracted success-write block. Only native/chain inputs are fixtures.
func CausalSDRSuccessSQL(s *SDRTask,ctx context.Context,miner,sector int64)(bool,error){sectorParams:=struct{SpID,SectorNumber int64}{miner,sector};ticketEpoch:=abi.ChainEpoch(100);ticket:=[]byte("fixture-randomness-not-a-proof");	n, err := s.db.Exec(ctx, `UPDATE sectors_sdr_pipeline
		SET after_sdr = true, ticket_epoch = $3, ticket_value = $4, task_id_sdr = NULL
		WHERE sp_id = $1 AND sector_number = $2`,
		sectorParams.SpID, sectorParams.SectorNumber, ticketEpoch, []byte(ticket))
	if err != nil {
		return false, xerrors.Errorf("store sdr success: updating pipeline: %w", err)
	}
	if n != 1 {
		return false, xerrors.Errorf("store sdr success: updated %d rows", n)
	}

return true,nil}
func CausalSDRSelection(s *SDRTask,ctx context.Context,ids []harmonytask.TaskID)([]harmonytask.TaskID,error){return s.FilterCandidates(ctx,ids)}
