//go:build causal && !skiff

package seal

import (
 "testing"
 "github.com/stretchr/testify/require"
 "github.com/filecoin-project/curio/harmony/harmonytask"
)

func TestCausalSDRSuccessCommitCrashBoundary(t *testing.T){
 ctx,db,_:=causalDB(t)
 task,id:=CausalCreateSDR(t,ctx,db,1000,42)
 var linked,count int
 require.NoError(t,db.QueryRow(ctx,`SELECT (SELECT count(*) FROM harmony_task WHERE id=$1),(SELECT count(*) FROM sectors_sdr_pipeline WHERE task_id_sdr=$1 AND NOT after_sdr)`,id).Scan(&count,&linked))
 require.Equal(t,1,count);require.Equal(t,1,linked,"normal poller/AddTask commits task and exact pipeline association together")
 done,err:=CausalSDRSuccessSQL(task,ctx,1000,42);require.NoError(t,err);require.True(t,done)
 // Model process loss after the real success UPDATE commits, before the
 // independent scheduler completion transaction. No completion call is made.
 require.NoError(t,db.QueryRow(ctx,`SELECT (SELECT count(*) FROM harmony_task WHERE id=$1),(SELECT count(*) FROM sectors_sdr_pipeline WHERE task_id_sdr=$1)`,id).Scan(&count,&linked))
 require.Equal(t,1,count);require.Zero(t,linked)
 var complete bool;require.NoError(t,db.QueryRow(ctx,`SELECT after_sdr FROM sectors_sdr_pipeline WHERE sp_id=1000 AND sector_number=42`).Scan(&complete));require.True(t,complete)
 _,err=task.taskToSector(id);require.Error(t,err,"actual storage resolver rejects the surviving task")
 t.Logf("source=%s normal creation -> production success SQL committed -> completion omitted: task=%d references=%d resolver=%v",causalVersion,count,linked,err)
}

func TestCausalSDROrphanAdmissionSelection(t *testing.T){
 ctx,db,_:=causalDB(t)
 task,bad:=CausalCreateSDR(t,ctx,db,1000,42)
 done,err:=CausalSDRSuccessSQL(task,ctx,1000,42);require.NoError(t,err);require.True(t,done)
 _,good:=CausalCreateSDR(t,ctx,db,1000,43)
 selected,err:=CausalSDRSelection(task,ctx,[]harmonytask.TaskID{bad,good});require.NoError(t,err)
 t.Logf("source=%s no personal pacing, actual source selection bad=%d good=%d selected=%v",causalVersion,bad,good,selected)
 require.Equal(t,[]harmonytask.TaskID{good},selected,"orphan must not consume admission before later valid work")
}

func TestCausalSDRDelayedPollSnapshotCanRelinkCompleted(t *testing.T){
 ctx,db,_:=causalDB(t)
 _,err:=db.Exec(ctx,`INSERT INTO sectors_sdr_pipeline(sp_id,sector_number,reg_seal_proof) VALUES(1000,77,0)`);require.NoError(t,err)
 var rows []pollTask
 require.NoError(t,db.Select(ctx,&rows,`SELECT sp_id,sector_number,after_sdr,task_id_sdr FROM sectors_sdr_pipeline WHERE sp_id=1000 AND sector_number=77`))
 require.Len(t,rows,1);snapshot:=rows[0];require.False(t,snapshot.AfterSDR);require.False(t,snapshot.TaskSDR.Valid)
 p:=&SealPoller{db:db};s:=&SDRTask{db:db,sp:p};s.Adder(harmonytask.CausalAdder(ctx,db,101))
 p.pollStartSDR(ctx,snapshot)
 var first harmonytask.TaskID;require.NoError(t,db.QueryRow(ctx,`SELECT task_id_sdr FROM sectors_sdr_pipeline WHERE sp_id=1000 AND sector_number=77`).Scan(&first))
 done,err:=CausalSDRSuccessSQL(s,ctx,1000,77);require.NoError(t,err);require.True(t,done)
 // A second poller's previously read snapshot resumes after the success write.
 // This uses the real producer; no malformed task/pipeline link is inserted.
 p.pollStartSDR(ctx,snapshot)
 var next harmonytask.TaskID;var afterSDR bool
 require.NoError(t,db.QueryRow(ctx,`SELECT task_id_sdr,after_sdr FROM sectors_sdr_pipeline WHERE sp_id=1000 AND sector_number=77`).Scan(&next,&afterSDR))
 require.NotEqual(t,first,next);require.True(t,afterSDR)
 selected,err:=CausalSDRSelection(s,ctx,[]harmonytask.TaskID{next});require.NoError(t,err)
 t.Logf("delayed normal poll snapshot linked new task %d after completed task %d; selected=%v",next,first,selected)
 require.Empty(t,selected,"completed re-linked task must not enter SDR admission")
}
