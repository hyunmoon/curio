//go:build causal && !skiff
package seal
import("context";"os";"testing";"time";"github.com/stretchr/testify/require";"github.com/filecoin-project/curio/harmony/harmonydb")
const causalVersion="after"
func causalDB(t *testing.T) (context.Context,*harmonydb.DB,*harmonydb.DB) {
 t.Helper()
 if os.Getenv("CURIO_CAUSAL_ITEST")!="1" {t.Skip("explicit disposable fixture opt-in required")}
 require.Equal(t,"127.0.0.1",os.Getenv("CURIO_CAUSAL_ITEST_HOST"))
 require.Equal(t,"59591",os.Getenv("CURIO_CAUSAL_ITEST_PORT"))
 require.Equal(t,"causal_disposable",os.Getenv("CURIO_CAUSAL_ITEST_DATABASE"))
 require.Equal(t,"causal_fixture",os.Getenv("CURIO_CAUSAL_ITEST_USER"))
 opts:=harmonydb.ItestOptions{Hosts:[]string{"127.0.0.1"},Port:"59591",Database:"causal_disposable",Username:"causal_fixture",ITestID:harmonydb.ITestNewID()}
 cfg:=opts.HarmonyConfig()
 cfg.ReadOnly=false;cfg.LoadBalance=false
 db,err:=harmonydb.NewFromConfig(cfg);require.NoError(t,err);t.Cleanup(db.ITestDeleteAll)
 cfg.ReadOnly=true
 other,err:=harmonydb.NewFromConfig(cfg);require.NoError(t,err);t.Cleanup(other.ITestDeleteAll)
 ctx,cancel:=context.WithTimeout(context.Background(),20*time.Second);t.Cleanup(cancel)
 _,err=db.Exec(ctx,`INSERT INTO harmony_machines(id,host_and_port,cpu,ram,gpu) VALUES(101,'worker-a.example',4,1024,0),(102,'worker-b.example',4,1024,0)`);require.NoError(t,err)
 var version,schema string;require.NoError(t,db.QueryRow(ctx,`SELECT version(),current_schema()`).Scan(&version,&schema));require.Contains(t,schema,"itest_");t.Logf("source=%s database=%s schema=%s; real embedded migration runner",causalVersion,version,schema)
 return ctx,db,other
}
