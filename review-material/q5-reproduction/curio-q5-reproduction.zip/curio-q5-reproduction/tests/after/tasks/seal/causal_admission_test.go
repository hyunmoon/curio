//go:build causal && !skiff
package seal
import("context";"testing";"github.com/stretchr/testify/require";"github.com/filecoin-project/curio/harmony/harmonytask")
// Only native Do and physical space reservation are substituted. CanAccept,
// candidate filtering, SQL claim/release, taskToSector and completion are real.
type causalSDRBody struct{*SDRTask;entered chan harmonytask.TaskID;finish <-chan struct{}}
func(s *causalSDRBody)Do(_ context.Context,id harmonytask.TaskID,_ func()bool)(bool,error){s.entered<-id;<-s.finish;return true,nil}
type causalReferenceStorage struct{s *SDRTask;claimed []harmonytask.TaskID}
func(s *causalReferenceStorage)HasCapacity()bool{return true}
func(s *causalReferenceStorage)Claim(id int)(func()error,error){s.claimed=append(s.claimed,harmonytask.TaskID(id));_,err:=s.s.taskToSector(harmonytask.TaskID(id));return func()error{return nil},err}
func TestCausalSDRActualHandlerOneSlotNoPacing(t *testing.T){ctx,db,_:=causalDB(t);s,bad:=CausalCreateSDR(t,ctx,db,1000,50);_,err:=CausalSDRSuccessSQL(s,ctx,1000,50);require.NoError(t,err);_,good:=CausalCreateSDR(t,ctx,db,1000,51)
 finish:=make(chan struct{});impl:=&causalSDRBody{SDRTask:s,entered:make(chan harmonytask.TaskID,1),finish:finish};storage:=&causalReferenceStorage{s:s}
 first:=harmonytask.CausalAdmissionTwoPasses(t,ctx,db,impl,storage,impl.entered,finish,[]harmonytask.TaskID{bad,good})
 t.Logf("source=%s one-slot real handler, no pacing: first_pass_started=%t storage_resolver_calls=%v; valid task completed; a second upstream pass can progress",causalVersion,first,storage.claimed)
 require.True(t,first,"orphan spent the first admission pass before valid work; not permanent starvation")
 require.Equal(t,[]harmonytask.TaskID{good},storage.claimed,"orphan reached storage claim")}
