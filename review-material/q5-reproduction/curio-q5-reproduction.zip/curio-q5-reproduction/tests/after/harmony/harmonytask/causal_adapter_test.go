//go:build causal && !skiff

package harmonytask
import("testing";"time";"github.com/stretchr/testify/require")
const causalVersion="after"
type causalIdentity=completionIdentity
type causalResult=taskCompletion
func causalClaim(t *testing.T,h *taskTypeHandler,row task)causalIdentity{t.Helper();gens:=map[TaskID]int64{};ids,err:=h.claimTaskOwnership([]TaskID{row.ID},1,gens,row);require.NoError(t,err);require.Equal(t,[]TaskID{row.ID},ids);store:=harmonyTaskAttemptStore{db:h.TaskEngine.cfg.db,owner:h.TaskEngine.cfg.ownerID,generations:gens};token:="causal-attempt";require.NoError(t,store.prepare(h.TaskEngine.cfg.ctx,row.ID,token));return completionIdentityFor(store,row.ID,token)}
func causalComplete(h *taskTypeHandler,row task,done bool,doErr error,preempted bool,identity causalIdentity)causalResult{return h.recordCompletion(row.ID,nil,time.Now(),done,doErr,preempted,identity)}
func causalEmit(h *taskTypeHandler,ee eventEmitter,_ task,result causalResult){h.emitRetryTask(ee,result.retry)}
func causalTell(p *peering,e schedulerEvent){p.TellNewTask(e.TaskType,e.TaskID,e.Retries,e.PostedTime,e.UpdateTime)}
func causalPublish(h *taskTypeHandler,row task,result causalResult,done bool,doErr error,_ bool){h.publishCompletion(result,row.ID,&completionMeta{vals:map[any]any{}},done,doErr,eventEmitter{schedulerChannel:h.TaskEngine.schedulerChannel})}
