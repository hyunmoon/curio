//go:build causal && !skiff
package harmonytask
import("context";"testing";"time";"github.com/stretchr/testify/require";"github.com/filecoin-project/curio/harmony/harmonydb";"github.com/filecoin-project/curio/harmony/resources";"github.com/filecoin-project/curio/harmony/taskhelp";"github.com/filecoin-project/curio/harmony/harmonytask/internal/runregistry";"github.com/filecoin-project/curio/harmony/harmonytask/internal/acceptcache")
// Test-only driver of actual considerWork. No engine/background services start.
func CausalAdmissionTwoPasses(t *testing.T,ctx context.Context,db *harmonydb.DB,impl TaskInterface,storage resources.Storage,entered <-chan TaskID,finish chan struct{},ids []TaskID)bool{
 t.Helper();e:=&TaskEngine{cfg:taskEngineConfig{ctx:ctx,db:db,ownerID:101,hostAndPort:"fixture.example",reg:&resources.Reg{Resources:resources.Resources{Cpu:1,Ram:1<<30}}},schedulerChannel:make(chan schedulerEvent,128)}
 h:=&taskTypeHandler{TaskEngine:e,TaskInterface:impl,TaskTypeDetails:TaskTypeDetails{Name:"SDR",Max:taskhelp.Max(1),MaxFailures:3,Cost:resources.Resources{Cpu:1,Storage:storage}},running:runregistry.New(),accept:acceptcache.New(time.Minute),storageFailures:map[TaskID]time.Time{}}
 e.handlers=[]*taskTypeHandler{h};e.taskMap=map[string]*taskTypeHandler{"SDR":h};var rows []task
 require.NoError(t,db.Select(ctx,&rows,"SELECT id,retries,posted_time,update_time FROM harmony_task WHERE id=ANY($1) ORDER BY id",ids))
 ee:=eventEmitter{schedulerChannel:e.schedulerChannel};first:=h.considerWork(workSourcePoller,rows,ee)
 if !first {var retry int;var unowned bool;require.NoError(t,db.QueryRow(ctx,"SELECT retries,owner_id IS NULL FROM harmony_task WHERE id=$1",ids[0]).Scan(&retry,&unowned));require.Zero(t,retry);require.True(t,unowned);require.True(t,h.considerWork(workSourcePoller,rows,ee),"next pass must still progress without personal pacing")}
 ticker:=time.NewTicker(time.Millisecond);defer ticker.Stop()
 for {h.drainAdmissions();select{case got:=<-entered:require.Equal(t,ids[1],got);close(finish);goto complete;case <-ticker.C:case <-ctx.Done():t.Fatal(ctx.Err())}}
 complete:
 for {select{case event:=<-e.schedulerChannel:if event.Source==schedulerSourceTaskCompleted{require.True(t,event.Success);return first};case <-ctx.Done():t.Fatal(ctx.Err())}}
}
