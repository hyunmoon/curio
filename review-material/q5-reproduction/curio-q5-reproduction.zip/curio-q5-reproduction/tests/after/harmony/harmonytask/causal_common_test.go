//go:build causal && !skiff

package harmonytask

import (
 "context"
 "errors"
 "os"
 "testing"
 "time"

 "github.com/stretchr/testify/require"
 "github.com/filecoin-project/curio/harmony/harmonydb"
 "github.com/filecoin-project/curio/harmony/harmonytask/internal/peerregistry"
 "github.com/filecoin-project/curio/harmony/resources"
 "github.com/filecoin-project/curio/harmony/taskhelp"
)

func causalDB(t *testing.T) (context.Context,*harmonydb.DB,*harmonydb.DB) {
 t.Helper()
 if os.Getenv("CURIO_CAUSAL_ITEST")!="1" {t.Skip("explicit disposable fixture opt-in required")}
 require.Equal(t,"127.0.0.1",os.Getenv("CURIO_CAUSAL_ITEST_HOST"))
 require.Equal(t,"59591",os.Getenv("CURIO_CAUSAL_ITEST_PORT"))
 require.Equal(t,"causal_disposable",os.Getenv("CURIO_CAUSAL_ITEST_DATABASE"))
 require.Equal(t,"causal_fixture",os.Getenv("CURIO_CAUSAL_ITEST_USER"))
 opts:=harmonydb.ItestOptions{Hosts:[]string{"127.0.0.1"},Port:"59591",Database:"causal_disposable",Username:"causal_fixture",ITestID:harmonydb.ITestNewID()}
 cfg:=opts.HarmonyConfig()
 cfg.ReadOnly=false;cfg.LoadBalance=false
 db,err:=harmonydb.NewFromConfig(cfg);require.NoError(t,err);t.Cleanup(db.ITestDeleteAll)
 cfg.ReadOnly=true
 other,err:=harmonydb.NewFromConfig(cfg);require.NoError(t,err);t.Cleanup(other.ITestDeleteAll)
 ctx,cancel:=context.WithTimeout(context.Background(),20*time.Second);t.Cleanup(cancel)
 _,err=db.Exec(ctx,`INSERT INTO harmony_machines(id,host_and_port,cpu,ram,gpu) VALUES(101,'worker-a.example',4,1024,0),(102,'worker-b.example',4,1024,0)`);require.NoError(t,err)
 var version,schema string;require.NoError(t,db.QueryRow(ctx,`SELECT version(),current_schema()`).Scan(&version,&schema));require.Contains(t,schema,"itest_");t.Logf("source=%s database=%s schema=%s; real embedded migration runner",causalVersion,version,schema)
 return ctx,db,other
}
func causalHandler(ctx context.Context,db *harmonydb.DB,owner int,max uint) *taskTypeHandler {
 e:=&TaskEngine{cfg:taskEngineConfig{ctx:ctx,db:db,ownerID:owner,hostAndPort:"fixture.example"},schedulerChannel:make(chan schedulerEvent,128),completionCallbacks:map[string][]TaskCompleteFunc{}}
 h:=&taskTypeHandler{TaskEngine:e,TaskTypeDetails:TaskTypeDetails{Name:"SDR",Max:taskhelp.Max(1),MaxFailures:max,RetryWait:func(int)time.Duration{return 25*time.Millisecond}}}
 e.handlers=[]*taskTypeHandler{h};e.taskMap=map[string]*taskTypeHandler{"SDR":h};return h
}
func causalCreate(t *testing.T,h *taskTypeHandler) task {
 t.Helper();h.TaskEngine.AddTaskByName("SDR",func(TaskID,*harmonydb.Tx)(bool,error){return true,nil})
 select {case event:=<-h.TaskEngine.schedulerChannel:return taskFromSchedulerEvent(event);case <-time.After(time.Second):t.Fatal("normal AddTask event missing")};return task{}
}
func causalSnapshot(t *testing.T,ctx context.Context,db *harmonydb.DB,id TaskID)task{
 t.Helper();var row task;require.NoError(t,db.QueryRow(ctx,`SELECT id,retries,posted_time,update_time FROM harmony_task WHERE id=$1`,id).Scan(&row.ID,&row.Retries,&row.PostedTime,&row.UpdateTime));return row
}
func TestCausalRetryCompletionPeerDeadline(t *testing.T){
 ctx,db,_:=causalDB(t);h:=causalHandler(ctx,db,101,3);row:=causalCreate(t,h);identity:=causalClaim(t,h,row)
 result:=causalComplete(h,row,false,errors.New("ordinary task failure"),false,identity)
 committed:=causalSnapshot(t,ctx,db,row.ID)
 require.Equal(t,1,committed.Retries)
 ch:=make(chan schedulerEvent,8);causalEmit(h,eventEmitter{schedulerChannel:ch},row,result)
 var local schedulerEvent;select {case local=<-ch:case <-ctx.Done():t.Fatal(ctx.Err())}
 sender,receiver:=pipePair();p:=&peering{peers:peerregistry.New()};remove:=p.peers.Add(102,"peer.example",sender,[]string{"SDR"});defer remove()
 causalTell(p,local)
 var wire []byte;select{case wire=<-receiver.recvCh:case <-ctx.Done():t.Fatal(ctx.Err())}
 dest:=&peering{h:&TaskEngine{schedulerChannel:ch}}
 require.NoError(t,dest.handlePeerMessage("peer.example",101,wire));peer:=taskFromSchedulerEvent(<-ch)
 due:=committed.UpdateTime.Add(h.RetryWait(committed.Retries));at:=time.Now()
 require.False(t,at.Before(due),"completion backoff has already elapsed before peer receipt")
 t.Logf("committed=%s wire=%s received=%s already_due=%t peer_due=%t",committed.UpdateTime.Format(time.RFC3339Nano),wire,peer.UpdateTime.Format(time.RFC3339Nano),!at.Before(due),!at.Before(peer.UpdateTime.Add(h.RetryWait(peer.Retries))))
 // Real DB discovery supplies the correct clock independently of delivery.
 polled:=h.TaskEngine.pollAllTaskTypes()["SDR"]
 require.Len(t,polled,1);require.True(t,polled[0].UpdateTime.Equal(committed.UpdateTime),"DB polling can repair the deadline")
 require.True(t,peer.UpdateTime.Equal(committed.UpdateTime),"peer discarded the committed failure timestamp")
 require.False(t,at.Before(peer.UpdateTime.Add(h.RetryWait(peer.Retries))),"peer restarted an already-satisfied wait")
}
func TestCausalStaleCompletionAfterMachineCleanup(t *testing.T){
 for _,mode:=range []string{"success","retryable-failure","terminal-failure","preemption"}{t.Run(mode,func(t *testing.T){
  ctx,db,other:=causalDB(t);max:=uint(3);if mode=="terminal-failure"{max=1};old:=causalHandler(ctx,db,101,max);row:=causalCreate(t,old);oldID:=causalClaim(t,old,row)
  // Inject only the documented fault: missed heartbeat while the old body can return late.
  _,err:=other.Exec(ctx,`UPDATE harmony_machines SET last_contact=CURRENT_TIMESTAMP-INTERVAL '1 millisecond'*$1 WHERE id=101`,resources.LOOKS_DEAD_TIMEOUT.Milliseconds()+1000);require.NoError(t,err)
  require.Equal(t,1,resources.CleanupMachines(ctx,other))
  var unowned bool;require.NoError(t,db.QueryRow(ctx,`SELECT owner_id IS NULL FROM harmony_task WHERE id=$1`,row.ID).Scan(&unowned));require.True(t,unowned)
  current:=causalHandler(ctx,other,102,max);currentRow:=causalSnapshot(t,ctx,other,row.ID);currentID:=causalClaim(t,current,currentRow)
  var before string;require.NoError(t,other.QueryRow(ctx,`SELECT to_jsonb(h)::text FROM harmony_task h WHERE id=$1`,row.ID).Scan(&before))
  callbacks:=0;old.TaskEngine.OnTaskComplete("SDR",func(context.Context,TaskID,bool){callbacks++})
  outcome:=errors.New("late execution failure");if mode=="success"{outcome=nil};if mode=="preemption"{outcome=context.Canceled}
  result:=causalComplete(old,row,mode=="success",outcome,mode=="preemption",oldID)
  causalPublish(old,row,result,mode=="success",outcome,mode=="preemption")
  var after string;var history int
  require.NoError(t,other.QueryRow(ctx,`SELECT COALESCE((SELECT to_jsonb(h)::text FROM harmony_task h WHERE id=$1),'MISSING'),(SELECT count(*) FROM harmony_task_history WHERE task_id=$1)`,row.ID).Scan(&after,&history))
  t.Logf("normal AddTask -> claim A -> real CleanupMachines -> claim B -> late A; mode=%s task_preserved=%t history=%d callbacks=%d",mode,before==after,history,callbacks)
  require.Equal(t,before,after,"old completion changed the new acquisition/retry state")
  require.Zero(t,history,"stale completion appeared as normal history");require.Zero(t,callbacks,"stale success published a callback")
  good:=causalComplete(current,currentRow,true,nil,false,currentID);causalPublish(current,currentRow,good,true,nil,false)
  require.NoError(t,other.QueryRow(ctx,`SELECT count(*) FROM harmony_task_history WHERE task_id=$1 AND result`,row.ID).Scan(&history));require.Equal(t,1,history,"current completion remains functional")
 })}
}
